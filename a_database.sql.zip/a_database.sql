-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2015 at 12:27 PM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `a_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(40) NOT NULL,
  `customer_address` varchar(40) NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `validity` date NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `customer_address`, `phone_number`, `validity`) VALUES
(1, 'Nahid', 'Noakhali', '01852474658', '2015-12-07'),
(2, 'faysal', 'rajshahi', '9776564754', '2015-12-08'),
(3, 'ram', 'nepal', '93809476', '2015-12-08'),
(4, 'Pavel', 'Feni', '099478y75', '2015-12-08'),
(5, 'Pulak', 'Dhaka', '01915742439', '2015-12-09'),
(6, 'Ajoy', 'Nepal', '01915742439', '2015-12-09'),
(7, 'Ajoy', 'Nepal', '01915742439', '2015-12-09'),
(8, 'Rakib', 'Dhaka', '01816675412', '2015-12-10'),
(9, 'Pranto', 'Maijdhee', '01842167588', '2015-12-10'),
(10, 'Deep', 'Noakhali', '01152157774', '2015-12-10'),
(11, 'Deep', 'Noakhali', '01152157774', '2015-12-10'),
(12, 'Deep', 'Noakhali', '01152157774', '2015-12-10'),
(13, 'Deep', 'Noakhali', '01152157774', '2015-12-10'),
(14, 'Deep', 'Noakhali', '01152157774', '2015-12-10');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `product_id` int(11) NOT NULL,
  `size` int(11) NOT NULL,
  `p_quantity` int(11) NOT NULL,
  `rate` decimal(10,0) NOT NULL,
  `details` varchar(50) NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `size`, `p_quantity`, `rate`, `details`) VALUES
(1001, 38, 30, '1250', 'apex shoe.'),
(1002, 39, 20, '1250', 'apex shoe.'),
(1003, 40, 48, '1500', 'converts '),
(1004, 41, 48, '1500', 'convert'),
(1005, 42, 47, '1500', 'convert'),
(1006, 40, 48, '1800', 'Apex sandle'),
(1007, 41, 46, '1800', 'Apex sandle'),
(1008, 38, 38, '2200', 'Appex Shoe'),
(1009, 42, 40, '2200', 'Apex Shoe'),
(1010, 43, 36, '2200', 'Appex Shoe'),
(1011, 44, 34, '2200', 'Apex Shoe'),
(1012, 38, 58, '700', 'Nano Roshi'),
(1013, 39, 57, '700', 'Nano Roshi');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `c_quantity` int(11) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`sale_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`sale_id`, `product_id`, `customer_id`, `c_quantity`, `price`, `date`, `user_id`) VALUES
(1, 1002, 4, 2, '2500', '2015-06-08', 1),
(2, 1001, 4, 3, '3750', '2015-06-08', 1),
(3, 1002, 5, 10, '12500', '2015-06-09', 1),
(4, 1010, 6, 4, '8800', '2015-06-09', 1),
(5, 1013, 6, 3, '2100', '2015-06-09', 1),
(6, 1012, 6, 2, '1400', '2015-06-09', 1),
(7, 1008, 8, 2, '4400', '2015-06-10', 1),
(8, 1011, 8, 1, '2200', '2015-06-10', 1),
(9, 1004, 8, 2, '3000', '2015-06-10', 1),
(10, 1003, 9, 2, '3000', '2015-06-10', 3),
(11, 1005, 9, 3, '4500', '2015-06-10', 3),
(12, 1007, 10, 1, '1800', '2015-06-10', 3),
(13, 1007, 10, 1, '1800', '2015-06-10', 3),
(14, 1007, 10, 1, '1800', '2015-06-10', 3),
(15, 1007, 10, 1, '1800', '2015-06-10', 3),
(16, 1006, 10, 2, '3600', '2015-06-10', 3);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(35) NOT NULL,
  `password` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'monir', '12345'),
(2, 'rony', '13579'),
(3, 'ajay', 'nstu');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
